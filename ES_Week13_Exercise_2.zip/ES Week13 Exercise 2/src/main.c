#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

const int MAXIMUM = 100;
char stack_buffer[100];
int top = -1;

int main()
{
	char word[] = {"banab"};
	int size = sizeof(word)/sizeof(word[0]);
	size--;
	for(int i = 0; i < size; i++)
	{
		if(stack_push(word[i]) == 0)
		{
			printf("Pushed %c\n", word[i]);

		}
		else
		{
			printf("Stack is full!");
		}
	}

	char half_stack[50];
	char trash;
	if(size%2 == 0)
	{
		for(int i = 0; i < size/2; i++)
		{
			stack_pop(&half_stack[i]);
		}
	}
	else
	{
		for(int i = 0; i < size/2; i++)
		{
			stack_pop(&half_stack[i]);
		}
		stack_pop(&trash);
	}

	int palindrome = 1;
	for(int i = 0; i < size/2; i++)
	{
		if(stack_buffer[top] == half_stack[top])
		{
			stack_pop(&trash);
		}
		else
		{
			palindrome = 0;
		}
	}

	if(palindrome)
	{
		printf("Palindrome\n");
	}
	else
	{
		printf("Not a palindrome\n");
	}

	return (0);
}

int stack_create (void)
{
    return 0;
}

void stack_destroy (void)
{
	top = -1;
}

int stack_push (const char elem)
{
	if(top<MAXIMUM)
	{
		top++;
		stack_buffer[top] = elem;
		return 0;
	}
	else
	{
		return -1;
	}
	
}

int stack_pop (char *elem)
{
	if(top > -1)
	{
		*elem = stack_buffer[top--];
		return 0;
	}
	else
	{
		return -1;
	}
}

int stack_top (char *elem)
{
    if(top > -1)
	{
		*elem = stack_buffer[top];
		return 0;
	}
	else
	{
		return -1;
	}
}