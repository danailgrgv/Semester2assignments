#include <stdio.h>
#include "stack.h"

struct st_listnode
{
	int element;
    struct st_listnode *pnext;
};

struct st_listnode *stack_buffer;

int main()
{
	double element = 1;

	// We push the numbers 1, 2 and 3 into the stack, in that order
	for(int i = 0; i < 3; i++)
	{
		if(stack_push(&element) == 0)
		{
			printf("Pushed %f\n", element);
			element++;
		}
		else
		{
			printf("Stack is full!");
		}
	}

	// We peek at the top element of the stack without popping it
	if(stack_top(&element) == 0)
	{
		printf("Top element of the stack : %f\n", element);
	}
	else
	{
		printf("Stack is empty, nothing on top to peek at");
	}

	// We pop the top 4 elements of the stack, but we only have 3 elements in the stack
	for(int i = 0; i < 4; i++)
	{
		if(stack_pop(&element) == 0)
		{
			printf("Popped %f\n", element);
		}
		else
		{
			printf("Stack is empty, nothing to pop\n");
		}	
	}

	return (0);
}

int stack_create (void)
{
    return 0;
}

void stack_destroy (void)
{
	free(stack_buffer->pnext);
}

int stack_push (const double *elem)
{
	struct st_listnode *new_node = (struct st_listnode *)malloc(sizeof(struct st_listnode));
	new_node->pnext = stack_buffer;
	new_node->element = *elem;
	stack_buffer = new_node;
	return 0;
}

int stack_pop (double *elem)
{
	if (stack_buffer)
	{
		struct st_listnode *pelem = stack_buffer;
		*elem = stack_buffer->element;
		stack_buffer = pelem->pnext;
		free(pelem);      
		return 0;
    }
	else
	{
		return -1;
	}
}

int stack_top (double *elem)
{
    if (stack_buffer)
	{
		*elem = stack_buffer->element;
		return 0;
    }
	else
	{
		return -1;
	}
}