#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

const int MAXIMUM = 100;
int stack_buffer[100];
int top = -1;

int main()
{
	double element = 1;

	// We push the numbers 1, 2 and 3 into the stack, in that order
	for(int i = 0; i < 3; i++)
	{
		if(stack_push(&element) == 0)
		{
			printf("Pushed %f\n", element);
			element++;
		}
		else
		{
			printf("Stack is full!");
		}
	}

	// We peek at the top element of the stack without popping it
	if(stack_top(&element) == 0)
	{
		printf("Top element of the stack : %f\n", element);
	}
	else
	{
		printf("Stack is empty, nothing on top to peek at");
	}

	// We pop the top 4 elements of the stack, but we only have 3 elements in the stack
	for(int i = 0; i < 4; i++)
	{
		if(stack_pop(&element) == 0)
		{
			printf("Popped %f\n", element);
		}
		else
		{
			printf("Stack is empty, nothing to pop");
		}	
	}

	return (0);
}

int stack_create (void)
{
    return 0;
}

void stack_destroy (void)
{
	top = -1;
}

int stack_push (const double *elem)
{
	if(top<MAXIMUM)
	{
		top++;
		stack_buffer[top] = *elem;
		return 0;
	}
	else
	{
		return -1;
	}
	
}

int stack_pop (double *elem)
{
	if(top > -1)
	{
		*elem = stack_buffer[top--];
		return 0;
	}
	else
	{
		return -1;
	}
}

int stack_top (double *elem)
{
    if(top > -1)
	{
		*elem = stack_buffer[top];
		return 0;
	}
	else
	{
		return -1;
	}
}